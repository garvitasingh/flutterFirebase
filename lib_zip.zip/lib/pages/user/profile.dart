import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../login.dart';

class Profile extends StatefulWidget {
  Profile({Key? key}) : super(key: key);

  @override
  _ProfileState createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  final user = FirebaseAuth.instance.currentUser!;
  final uid = FirebaseAuth.instance.currentUser!.uid;
  final email = FirebaseAuth.instance.currentUser!.email;
  final name = FirebaseAuth.instance.currentUser!.displayName;
  var snapshot =  FirebaseFirestore.instance.collection('Data').doc(uid)
          .collection('userData')
          .snapshots() as Stream<DocumentSnapshot<Object?>>;


  verifyEmail() async {
    if (user != null && !user.emailVerified) {
      await user.sendEmailVerification();
      print('Verification Email has been sent');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Colors.orangeAccent,
          content: Text(
            'Check email for Verification',
            style: TextStyle(fontSize: 18.0, color: Colors.black),
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    print(FirebaseFirestore.instance
        .collection('Data')
        .doc(uid)
        .collection('userData'));
    return Container(
      alignment: Alignment.center,
      margin: EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
      child: Column(
        children: [
          StreamBuilder(
              stream: FirebaseFirestore.instance
                  .collection('Data')
                  .doc(uid)
                  .collection('userData')
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return Center(
                    child: CircularProgressIndicator(),
                  );
                }
                return ListView(
                  children: snapshot.data.docs.map((document) {
                    return Container(
                      child: Center(child: Text(document['adddress'])),
                    );
                  }).toList(),
                );
              }),
          // CircleAvatar(
          //   backgroundImage: NetworkImage(user.photoURL!),
          //   radius: 20,
          // ),
          Spacer(),
          Text(
            'Name: $name',
            style: TextStyle(fontSize: 18.0),
          ),
          Text(
            'User ID: $uid',
            style: TextStyle(fontSize: 18.0),
          ),
          SizedBox(
            height: 10,
          ),
          Text(
            'Email: $email',
            style: TextStyle(fontSize: 18.0),
          ),
          SizedBox(
            height: 5,
          ),
          user.email != null
              ? user.emailVerified
                  ? Text(
                      'Email verified',
                      style: TextStyle(fontSize: 18.0, color: Colors.blueGrey),
                    )
                  : TextButton(
                      onPressed: () => {verifyEmail()},
                      child: Text('Verify Email'))
              : Text('Logged in with mobile number'),
          // Text(
          //   'Created on: $creationTime',
          //   style: TextStyle(fontSize: 18.0),
          // ),
          Spacer(),
          ElevatedButton(
            onPressed: () async => {
              await FirebaseAuth.instance.signOut(),
              Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (context) => Login(),
                  ),
                  (route) => false)
            },
            child: Text('LogOut'),
            style: ElevatedButton.styleFrom(
              primary: Colors.deepPurple.withOpacity(0.5),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(27)),
            ),
          ),
          ElevatedButton(
              onPressed: () async {
                await user.delete();
              },
              child: Text('Delete User')),
        ],
      ),
    );
  }
}
